INSERT INTO departments (name) VALUES ('HR');
INSERT INTO departments (name) VALUES ('IT');

INSERT INTO employees (name, email, department_id) VALUES ('Meenakshi Sharma', 'meenasharma@gmail.com', 1);
INSERT INTO employees (name, email, department_id) VALUES ('Komal Sharma', 'kskomal23@gmail.com', 2);
